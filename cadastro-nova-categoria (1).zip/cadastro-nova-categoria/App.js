import Lembrete from './components/Lembrete.js'
import RegularTextInput from './components/Textinput'
import Button from './components/Button'


//const App = () =>{
//return <SelectDropdown/>;

//}

//export default App

import React, { FC, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Dropdown from './components/Dropdown';

const App: FC = () => {
  const [selected, setSelected] = useState(undefined);
  const data = [
    { label: 'Amarelo', value: '1' },
    { label: 'Azul', value: '2' },
    { label: 'Roxo', value: '3' },
    { label: 'Marrom', value: '4' },
  ];

  return (
    <View>
      <Dropdown label="Cor" data={data} onSelect={setSelected} />
    </View>
  );
};



export default Button;